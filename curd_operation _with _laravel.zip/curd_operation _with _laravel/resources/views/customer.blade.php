<!doctype html>
<html lang="en">
<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body class="bg-light">
  
  <form action="{{$url}}" method="post">
    @csrf
    <div class="container">
      <h3 class="form-group col-md-6 required">{{$title}}</h3>
      <div class="form-group col-md-6 required">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" class="form-control" value="{{$customer->name}}" />
        <span class="text-danger">
          @error('name')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-group col-md-6 required">
        <label for="email">Email</label>
        <input type="text" name="email" id="email" class="form-control" value="{{$customer->email}}" />
        <span class="text-danger">
          @error('email')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-group col-md-6 required">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" class="form-control" />
        <span class="text-danger">
          @error('password')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-group col-md-6 required">
        <label for="password_confirmation">Confirm Password</label>
        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" />
        <span class="text-danger">
          @error('password_confirmation')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-group col-md-6 required">
        <label for="country">Country</label>
        <input type="text" name="country" id="country" class="form-control" value="{{$customer->country}}" />
        <span class="text-danger">
          @error('country')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-group col-md-6 required">
        <label for="state">State</label>
        <input type="text" name="state" id="state" class="form-control" value="{{$customer->state}}" />
        <span class="text-danger">
          @error('state')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-group col-md-6 required">
        <label for="address">Address</label>
        <textarea name="address" id="address" class="form-control">{{$customer->address}}</textarea>
        <span class="text-danger">
          @error('address')
          {{$message}}
          @enderror
        </span>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="male" value="M" {{$customer->gender == "M" ? "checked" : ""}} />
        <label class="form-check-label" for="male">Male</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="female" value="F" {{$customer->gender == "F" ? "checked" : ""}} />
        <label class="form-check-label" for="female">Female</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="other" value="O" {{$customer->gender == "O" ? "checked" : ""}} />
        <label class="form-check-label" for="other">Other</label>
      </div>
      <button class="btn btn-primary" type="submit">Submit</button>
    </div>
  </form>
</body>
</html>
