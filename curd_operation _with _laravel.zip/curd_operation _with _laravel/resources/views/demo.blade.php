<h1>
    laravel 8
</h1>

<h3> 
    {{ $name }}
</h3>

<h3> 
    {{ $id }}
</h3>