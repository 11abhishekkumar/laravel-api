<!DOCTYPE html>
<html lang="en">
<head>
  <title>View</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">User Data</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/customer/view">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/customer">Add User</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

  <div class="container">

    <div class="row m-2">
       <form action="" class="col-9">
        <div class="form-group">
          <input type="search " name="search" id="" class="form-control"placeholder="Search by name or email" value="{{$search}}"/>
        </div>
        <button class="btn btn-primary">Search</button>
        <a href="{{url('/customer/view')}}"> 
        <button class="btn btn-primary" type="button">Reset</button>
</a>
       </form>
      <div class="col-3">
    <a href="{{ route('customer.create') }}">
      <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
    </a>
    <a href="{{ url('customer/trash') }}">
      <button class="btn btn-danger d-inline-block m-2 float-right">Go To Trash</button>
    </a>
</div>
</div>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Address</th>
          <th>State</th>
          <th>Country</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @php
        $i = 1;
        @endphp
        @foreach($customers as $customer)
        <tr>
          <td>{{ $customer->name }}</td>
          <td>{{ $customer->email }}</td>
          <td>
            @if($customer->gender == "M")                
              Male
            @elseif($customer->gender == "F") 
              Female
            @else
              Other
            @endif
          </td>
          <td>{{ $customer->address }}</td>
          <td>{{ $customer->state }}</td>
          <td>{{ $customer->country }}</td>
          <td>
            @if($customer->status == "1")
              <a href="#">
                <span class="badge badge-success">Active</span>
              </a>
            @else 
              <a href="#">
                <span class="badge badge-danger">Inactive</span>
              </a>
            @endif
          </td>
          <td>
            <a href="{{ route('customer.delete', ['id' => $customer->id]) }}"><button class="btn btn-danger">Move To Trash</button></a>
            <a href="{{ route('customer.edit', ['id' => $customer->id]) }}"><button class="btn btn-primary">Edit</button></a>
          </td>
        </tr>
        @php
        $i++;
        @endphp
        @endforeach
      </tbody>
    </table> 
    <div class="row">
      {{$customers->links()}}
</div>
  </div> 
</body>
</html>
