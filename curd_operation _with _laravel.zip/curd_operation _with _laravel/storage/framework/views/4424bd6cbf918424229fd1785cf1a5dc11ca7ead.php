<h1>
    laravel 8
</h1>

<h3> 
    <?php echo e($name); ?>

</h3>

<h3> 
    <?php echo e($id); ?>

</h3><?php /**PATH C:\wamp64\www\abhishek\resources\views/demo.blade.php ENDPATH**/ ?>