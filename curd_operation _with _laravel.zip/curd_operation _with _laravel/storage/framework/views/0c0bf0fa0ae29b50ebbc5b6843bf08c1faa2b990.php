<!doctype html>
<html lang="en">
  <head>
    <title>Customer Tresh</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
     <div class="container">
      <a href="<?php echo e(route('customer.create')); ?>">
        <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
      </a>
      <a href="<?php echo e(url('customer/view')); ?>">
        <button class="btn btn-primary d-inline-block m-2 float-right">Customer view</button>
      </a>
       <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Address</th>
                <th>State</th>
                <th>Country</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->email); ?></td>
                <td>
                  <?php if($customer->gender == "M"): ?>                
                    Male
                  <?php elseif($customer->gender == "F"): ?> 
                    Female
                  <?php else: ?>
                    Other
                  <?php endif; ?>
                </td>
                <td><?php echo e($customer->address); ?></td>
                <td><?php echo e($customer->state); ?></td>
                <td><?php echo e($customer->country); ?></td>
                <td>
                  <?php if($customer->status == "1"): ?>
                    <a href="">
                      <span class="badge badge-success">Active</span>
                    </a>
                  <?php else: ?> 
                    <a href="">
                      <span class="badge badge-danger">Inactive</span>
                    </a>
                  <?php endif; ?>
                </td>
                <td>
                  <a href="<?php echo e(route('customer.force-delete', ['id' => $customer->id])); ?>">
                    <button class="btn btn-danger">Delete</button>
                  </a>
                  <a href="<?php echo e(route('customer.restore', ['id' => $customer->id])); ?>">
                    <button class="btn btn-primary">Restore</button>
                  </a>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
       </table> 
     </div> 
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4Vqn3vMGnXw1R6RSJoP5" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0Cp3jhIN3NhoKgO6z8p4Jo4oTcuDCh7o1b8gBvUstXBgFOj9I5cY5c9MK7" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH C:\wamp64\www\laravel\curd_operation _with _laravel\resources\views/customer-trash.blade.php ENDPATH**/ ?>