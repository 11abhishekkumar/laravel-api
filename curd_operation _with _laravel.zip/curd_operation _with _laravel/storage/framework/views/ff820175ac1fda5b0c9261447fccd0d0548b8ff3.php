<!DOCTYPE html>
<html lang="en">
<head>
  <title>View</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">User Data</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/customer/view">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/customer">Add User</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

  <div class="container">

    <div class="row m-2">
       <form action="" class="col-9">
        <div class="form-group">
          <input type="search " name="search" id="" class="form-control"placeholder="Search by name or email" value="<?php echo e($search); ?>"/>
        </div>
        <button class="btn btn-primary">Search</button>
        <a href="<?php echo e(url('/customer/view')); ?>"> 
        <button class="btn btn-primary" type="button">Reset</button>
</a>
       </form>
      <div class="col-3">
    <a href="<?php echo e(route('customer.create')); ?>">
      <button class="btn btn-primary d-inline-block m-2 float-right">Add</button>
    </a>
    <a href="<?php echo e(url('customer/trash')); ?>">
      <button class="btn btn-danger d-inline-block m-2 float-right">Go To Trash</button>
    </a>
</div>
</div>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Address</th>
          <th>State</th>
          <th>Country</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $i = 1;
        ?>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($customer->name); ?></td>
          <td><?php echo e($customer->email); ?></td>
          <td>
            <?php if($customer->gender == "M"): ?>                
              Male
            <?php elseif($customer->gender == "F"): ?> 
              Female
            <?php else: ?>
              Other
            <?php endif; ?>
          </td>
          <td><?php echo e($customer->address); ?></td>
          <td><?php echo e($customer->state); ?></td>
          <td><?php echo e($customer->country); ?></td>
          <td>
            <?php if($customer->status == "1"): ?>
              <a href="#">
                <span class="badge badge-success">Active</span>
              </a>
            <?php else: ?> 
              <a href="#">
                <span class="badge badge-danger">Inactive</span>
              </a>
            <?php endif; ?>
          </td>
          <td>
            <a href="<?php echo e(route('customer.delete', ['id' => $customer->id])); ?>"><button class="btn btn-danger">Move To Trash</button></a>
            <a href="<?php echo e(route('customer.edit', ['id' => $customer->id])); ?>"><button class="btn btn-primary">Edit</button></a>
          </td>
        </tr>
        <?php
        $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table> 
    <div class="row">
      <?php echo e($customers->links()); ?>

</div>
  </div> 
</body>
</html>
<?php /**PATH C:\wamp64\www\laravel\curd_operation _with _laravel\resources\views/customer-view.blade.php ENDPATH**/ ?>