<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistrationController extends Controller
{
    public function index()
    {
        return view('customer');
    }
    public function customer(Request $request)
    {
        $request->validate(
            [
                'name' => 'required',
                'email' => 'required|email',
                'password' => 'required|confirmed',
                'password_confirmation' => 'required',
                'cuntry' => 'required',
                'state' => 'required',
                'address' => 'required',
                


            ]
        );
        echo"<pre>";
     print_r($request->all());
    }
}
 